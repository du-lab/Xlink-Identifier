Concatenated Text File Splitter

This program is a command-line utility reads in a concatenated text file 
(e.g. _dta.txt file or _out.txt file) and splits the file into individual 
output files.  Note that _dta.txt and _out.txt files are specific to the 
Smith group since our current solution to data archival includes 
concatenation of the tandem mass spectral data files produced during 
SEQUEST (TM) analysis into a single text file.  This command-line program 
can be used to reverse this process to split apart the _dta.txt file into 
individual .dta files.  We also routinely concatenate SEQUEST analysis 
output files (.out files) in a similar fashion. 

Double click the ConcatenatedTextFileSplitter_Installer.msi file to install.
The program shortcut can be found at:
 Start Menu -> Programs -> PAST Toolkit -> Concatenated Text File Splitter

To run:
1) Open a command prompt window
2) Enter the path that points to the program (e.g. cd c:\Program Files\ConcatenatedFileSplitter\
    for typical installation)
3) Enter the executable filename (i.e. ConcatenatedTextFileSplitter.exe), then a 
   space, then /I: followed by the full path to the text file in question (e.g 
   ConcatenatedTextFileSplitter.exe /I:c:\Temp\YourDirectory\Fileofinterest_dta.txt)
4) Wait until the program is finished.

Note: Running the program with no input file path will open a dialog with further 
options available to the user. Double clicking on the program in an Explorer-style 
window will also show the user options, but the program will terminate upon 
closing the dialog, so the command line option outlined above is still required.

-------------------------------------------------------------------------------
Written by Matthew Monroe for the Department of Energy (PNNL, Richland, WA)
Program started April 2, 2004

E-mail: matthew.monroe@pnl.gov or matt@alchemistmatt.com
Website: http://ncrr.pnl.gov/ or http://www.sysbio.org/resources/staff/
-------------------------------------------------------------------------------

Licensed under the Apache License, Version 2.0; you may not use this file except 
in compliance with the License.  You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0

All publications that result from the use of this software should include 
the following acknowledgment statement:
 Portions of this research were supported by the W.R. Wiley Environmental 
 Molecular Science Laboratory, a national scientific user facility sponsored 
 by the U.S. Department of Energy's Office of Biological and Environmental 
 Research and located at PNNL.  PNNL is operated by Battelle Memorial Institute 
 for the U.S. Department of Energy under contract DE-AC05-76RL0 1830.

Notice: This computer software was prepared by Battelle Memorial Institute, 
hereinafter the Contractor, under Contract No. DE-AC05-76RL0 1830 with the 
Department of Energy (DOE).  All rights in the computer software are reserved 
by DOE on behalf of the United States Government and the Contractor as 
provided in the Contract.  NEITHER THE GOVERNMENT NOR THE CONTRACTOR MAKES ANY 
WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY LIABILITY FOR THE USE OF THIS 
SOFTWARE.  This notice including this sentence must appear on any copies of 
this computer software.
