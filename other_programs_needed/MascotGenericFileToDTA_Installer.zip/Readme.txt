MascotGenericFile to DTA Converter

This program is a command-line utility that reads in a Mascot Generic Format (MGF)
file and creates the equivalent _Dta.txt or .Dta files.  Both formats (MGF and DTA)
are common text file formats for listing peak lists of mass spectrometry data 
(lists of mass and intensity pairs), generally from MS/MS spectra.  

This program was written in VB.NET and requires the Microsoft .NET Framework 4.0, 
which you can download from:
http://www.microsoft.com/en-us/download/details.aspx?id=17718

Double click the MascotGenericFileToDTA_Installer.msi file to install.
The program shortcut can be found at:
 Start Menu -> Programs -> PAST Toolkit -> MascotGenericFile to DTA Converter

To run:
1) Open a command prompt window
2) Enter the path that points to the program (e.g. cd c:\Program Files\MascotGenericFileToDTA\
    for typical installation)
3) Enter the executable filename (i.e. MascotGenericFileToDTA.exe), then a 
   space, then the full path to the text file in question, for example:
   MascotGenericFileToDTA.exe c:\Temp\YourDirectory\FileOfInterest.mgf

   If the path contains spaces, then surround the path with double quotes, for example:
   MascotGenericFileToDTA.exe c:\My Documents\YourDirectory\FileOfInterest.mgf

4) Wait until the program is finished.


Note: Running the program with no input file path will open a dialog with further 
options available to the user. Double clicking on the program in an Explorer-style 
window will also show the user options, but the program will terminate upon 
closing the dialog, so the command line option outlined above is still required.

-------------------------------------------------------------------------------
Written by Matthew Monroe for the Department of Energy (PNNL, Richland, WA)
Program started in November 2003

' E-mail: matthew.monroe@pnnl.gov or matt@alchemistmatt.com
' Website: http://panomics.pnnl.gov/ or http://www.sysbio.org/resources/staff/
-------------------------------------------------------------------------------

Licensed under the Apache License, Version 2.0; you may not use this file except 
in compliance with the License.  You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0

Notice: This computer software was prepared by Battelle Memorial Institute, 
hereinafter the Contractor, under Contract No. DE-AC05-76RL0 1830 with the 
Department of Energy (DOE).  All rights in the computer software are reserved 
by DOE on behalf of the United States Government and the Contractor as 
provided in the Contract.  NEITHER THE GOVERNMENT NOR THE CONTRACTOR MAKES ANY 
WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY LIABILITY FOR THE USE OF THIS 
SOFTWARE.  This notice including this sentence must appear on any copies of 
this computer software.
